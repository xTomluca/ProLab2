﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Entidades;

namespace Archivos
{
    public class Texto :IArchivo<Queue<Patente>>
    {
        public void Guardar(string archivo, Queue<Patente> datos)
        {
            StreamWriter streamWriter = new StreamWriter(archivo);
            foreach(Patente p in datos)
            {
                streamWriter.WriteLine(p.CodigoPatente);
            }
            streamWriter.Close();
        }
        public void Leer(string archivo, out Queue<Patente> datos)
        {
            StreamReader streamReader = new StreamReader(archivo);
            datos = new Queue<Patente>();
            do
            {
                 Patente p = new Patente();
                 p = PatenteStringExtension.ValidarPatente(streamReader.ReadLine());
                 datos.Enqueue(p);
                
            } while (streamReader.EndOfStream);

        }
    }
}
