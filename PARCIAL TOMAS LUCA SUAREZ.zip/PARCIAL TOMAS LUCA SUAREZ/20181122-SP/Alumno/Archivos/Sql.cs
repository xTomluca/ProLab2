﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;
using Entidades;

namespace Archivos
{
    public class Sql : IArchivo<Queue<Patente>>
    {
        private SqlCommand comando;
        private SqlConnection conexion;

        public void Guardar(string tabla, Queue<Patente> datos)
        {
            string connection = "Data Source=.\\SQLEXPRESS; Initial Catalog =patentes-sp-2018; Integrated Security=True";
            this.conexion = new SqlConnection(connection);
            this.conexion.Open();
            this.comando = new SqlCommand();
            this.comando.Connection = conexion;
            this.comando.CommandType = CommandType.Text;
            foreach(Patente p in datos)
            {
                this.comando.CommandText = string.Format("INSERT INTO {0}(patente,tipo) VALUES('{1}','{2}')",tabla,p.CodigoPatente,p.TipoCodigo);
                this.comando.ExecuteNonQuery();
            }
            conexion.Close();

        }
        public void Leer(string tabla, out Queue<Patente> datos)
        {
            string connection = "Data Source=.\\SQLEXPRESS; Initial Catalog =patentes-sp-2018; Integrated Security=True";
            this.conexion = new SqlConnection(connection);
            this.conexion.Open();
            this.comando = new SqlCommand();
            this.comando.Connection = conexion;
            this.comando.CommandText = "SELECT * FROM dbo.Patentes";
            this.comando.CommandType = System.Data.CommandType.Text;
            SqlDataReader sqlDataReader = this.comando.ExecuteReader();
            datos = new Queue<Patente>();
            while (sqlDataReader.Read())
            { 
                Patente patente = new Patente();
                if (sqlDataReader["tipo"].ToString() == "Vieja")
                    patente = new Patente(sqlDataReader["patente"].ToString(), Patente.Tipo.Vieja);
                else if (sqlDataReader["tipo"].ToString() == "Mercosur")
                    patente = new Patente(sqlDataReader["patente"].ToString(), Patente.Tipo.Mercosur);
                datos.Enqueue(patente);
            }
            sqlDataReader.Close();
        }

    }
}
