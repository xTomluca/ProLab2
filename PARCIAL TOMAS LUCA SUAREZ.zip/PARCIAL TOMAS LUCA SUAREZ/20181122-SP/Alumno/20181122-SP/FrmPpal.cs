﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Patentes;
using Entidades;
using Archivos;
using System.Threading;

namespace _20181122_SP
{
    public partial class FrmPpal : Form
    {
        List<Thread> listaThreads;
        Queue<Patente> cola;

        public FrmPpal()
        {
            InitializeComponent();
            this.listaThreads = new List<Thread>();
            this.cola = new Queue<Patente>();
        }

        private void FrmPpal_Load(object sender, EventArgs e)
        {
            this.vistaPatenteDerecha.finExposicion += this.ProximaPatente;
            this.vistaPatenteIzq.finExposicion += this.ProximaPatente;
        }

        private void FrmPpal_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.FinalizarSimulacion();
        }

        private void btnXml_Click(object sender, EventArgs e)
        {
            Xml<Patente> xml = new Xml<Patente>();
            Patente p = new Patente();
            try
            {
                xml.Leer("./patentes.xml",out p);
                this.cola.Enqueue(p);
            }
            catch(Exception a)
            {
                MessageBox.Show(a.Message);
            }

        }

        private void btnTxt_Click(object sender, EventArgs e)
        {
            Texto texto = new Texto();
            Queue<Patente> aux = new Queue<Patente>();
            try
            {
                texto.Leer("./patentes.txt", out aux);
                foreach (Patente p in aux)
                    this.cola.Enqueue(p);
            }
            catch(PatenteInvalidaException p)
            {
                MessageBox.Show(p.Message);
            }
            catch(Exception a)
            {
                MessageBox.Show(a.Message);

            }
        }

        private void btnSql_Click(object sender, EventArgs e)
        {
            Sql sql = new Sql();
            Queue<Patente> aux = new Queue<Patente>();
            try
            {
                sql.Leer("Patentes",out aux);
                foreach (Patente p in aux)
                    this.cola.Enqueue(p);
            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);
            }
        }

        private void FinalizarSimulacion()
        {
            foreach(Thread t in this.listaThreads)
            {
                if (t.IsAlive)
                    t.Abort();
            }
        }
        public void ProximaPatente(VistaPatente vp)
        {
            if(this.cola.Count!=0)
            {
                Thread thread = new Thread(new ParameterizedThreadStart(vp.MostrarPatente));
                thread.Start(this.cola.Dequeue());
                this.listaThreads.Add(thread);    
            }
            
        }
        public void InciarSimulacion()
        {
            this.FinalizarSimulacion();
            this.ProximaPatente(vistaPatenteDerecha);
            this.ProximaPatente(vistaPatenteIzq);
        }
    }
}
